```

BenchmarkDotNet v0.15.4, Linux Ubuntu 24.04.5 LTS (Noble Numbat) (container)
11th Gen Intel Core i9-11900 2.50GHz (Max: 0.80GHz), 1 CPU, 16 logical and 8 physical cores
.NET SDK 10.0.401
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-IRUZYG : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

Affinity=100  Concurrent=True  Server=False  
IterationCount=12  IterationTime=500ms  LaunchCount=1  
WarmupCount=16  

```
| Method       | Mean     | Error    | StdDev   | Allocated |
|------------- |---------:|---------:|---------:|----------:|
| SyncHit      | 37.99 ns | 0.329 ns | 0.238 ns |         - |
| GenericHit   | 56.41 ns | 3.720 ns | 2.690 ns |         - |
| TaskHit      | 42.59 ns | 1.733 ns | 1.146 ns |         - |
| ValueTaskHit | 46.39 ns | 0.659 ns | 0.436 ns |         - |
